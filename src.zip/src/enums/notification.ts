export enum NotificationType {
    Message = 1,
    Invite = 2,
}
export enum PostType {
    Service = 1,
    Product = 2,
    Arts = 3,
    Photo = 4,
    Video = 5
}
