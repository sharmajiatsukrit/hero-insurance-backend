export interface NotificationResourceType {
    resource_data?: any;
    resource_url?: string;
    resource_img?: string;
    resource_file_id?: string;
}
