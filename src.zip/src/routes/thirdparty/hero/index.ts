import expres, { Router } from "express";
import HeroController from "../../../controllers/thirdparty/hero";
import { UserRouteEndPoints, AdminRouteEndPoints } from "../../../enums/user";
import { authRequest, validateRequest } from "../../../utils/middleware";
import { upload } from "../../../utils/storage";

const routes: Router = expres.Router();
const heroController = new HeroController();

routes.post("/lead-generation", validateRequest, heroController.leadGeneration.bind(heroController));
routes.post("/token-validation", validateRequest, heroController.tokenValidation.bind(heroController));
routes.post("/token-validation-otp-verify", validateRequest, heroController.verifyTokenValidationOTP.bind(heroController));
routes.post("/health-quote", validateRequest, heroController.healthQuote.bind(heroController));
routes.post("/misp-login", validateRequest, heroController.mispLogin.bind(heroController));
routes.post("/misp-auth", validateRequest, heroController.mispAuth.bind(heroController));
routes.post("/renewal-link", validateRequest, heroController.renewalLink.bind(heroController));
routes.post("/cp-details", validateRequest, heroController.cpDetails.bind(heroController));
routes.post("/register-claim", validateRequest, heroController.registerCliam.bind(heroController));
routes.post("/cleaver-tap-event", validateRequest, heroController.cleaverTapEvent.bind(heroController));

routes.post("/get-details", validateRequest, heroController.getDetails.bind(heroController));
routes.post("/get-policy-list", validateRequest, authRequest, heroController.getPolicyList.bind(heroController));
routes.post("/get-notification-list", validateRequest, authRequest, heroController.getNotificationList.bind(heroController));
routes.post("/notification-viewed", validateRequest, authRequest, heroController.markNotificationViewed.bind(heroController));
routes.get("/get-misp-policy-details/:policy_id", validateRequest, authRequest, heroController.getMispPolicyDetails.bind(heroController));
// Claim Related Api
routes.post("/ClaimPolicy/StateList", validateRequest, authRequest, heroController.getStateList.bind(heroController));
routes.post("/ClaimPolicy/CityList", validateRequest, authRequest, heroController.getCityList.bind(heroController));
routes.post("/ClaimPolicy/DelearDetails", validateRequest, authRequest, heroController.getDelearDetailsList.bind(heroController));
routes.post("/ClaimPolicy/SaveClaim", validateRequest, authRequest, heroController.saveCalimRequest.bind(heroController));
routes.post("/ClaimPolicy/ClaimOnPolicyDetailsbyMobileNo", validateRequest, authRequest, heroController.getCalimRequestList.bind(heroController));


routes.post("/get-proposal-token", validateRequest, heroController.generateProposalToken.bind(heroController));
routes.post("/proposal-report", validateRequest, heroController.proposalReport.bind(heroController));
// routes.get("/get-offer-filters/:product_id", validateRequest, authRequest, dashboardController.getOfferFilters.bind(dashboardController));


routes.post("/misp/login-policy", validateRequest, heroController.mispLoginPolicy.bind(heroController));
routes.get("/misp/download-policy", validateRequest, heroController.mispDownloadPolicy.bind(heroController));

routes.post("/send-policy-mail", validateRequest, heroController.sendPolicyDetails.bind(heroController));
routes.post("/add-new-policy", validateRequest, authRequest, heroController.addNewPolicy.bind(heroController));

export default routes;